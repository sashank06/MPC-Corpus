
//class that converts the xml from govt test format to text format

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

public class XMLToText 
{
    static String inDir = "";
    static String outDir = "";
    
    XMLToText ()
    {
	if (!inDir.equals ("") && !outDir.equals (""))
	    {
		File inFileDir = new File (inDir);
		File outFileDir = new File (outDir);
		String files [] = inFileDir.list ();
		PrintWriter outFile = null;
		for (int i = 0; i < files.length; i++)
		    {
			String filename = files [i];
			System.out.println ("Working on " + filename);
			File xmlfile = new File (inFileDir.getAbsolutePath () + "/" + filename);
			filename = filename.substring (0, filename.indexOf ("."));
			try 
			    {
				outFile = new PrintWriter 
				    (new OutputStreamWriter
				     (new FileOutputStream
				      (new File (outFileDir.getAbsolutePath () + "/" + filename + "_modified.xml")), "UTF-8"));

				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance ();
				DocumentBuilder parser = factory.newDocumentBuilder ();
				Document document = parser.parse (xmlfile);
				
				NodeList nodes = document.getElementsByTagName ("turn");
				System.out.println ("SIZE " + nodes.getLength ());
				outFile.println ("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
				outFile.println ("<Dialogue date=\"2009-04-28\" >");
				for (int j = 0; j < nodes.getLength (); j++)
				    {
					Element el = (Element) nodes.item (j);
					
					String speaker = el.getAttribute ("speaker");
					String timestamp = el.getAttribute ("end_time");
					
					Node utterance = el.getChildNodes ().item (0);
					if (utterance != null)
					    outFile.println ("<turn mode=\"chat\" speaker=\"" + speaker + "\"" +
							     " end_time=\"" + timestamp + "\" turn_no=\"" + (j+1) +
							     "\" dialog_act=\"\" comm_act_type=\"\" link_to=\"\" pos=\"\"" +
							     " pos_count=\"\" pos_origin=\"\" topic=\"\" polarity=\"\">" + 
							     utterance.getNodeValue () + "</turn>");
				    }
				outFile.println ("</Dialogue>");

			    }
			catch (Exception ee)
			    {
				ee.printStackTrace ();
			    }
			finally 
			    {
			
				if (outFile != null) outFile.close ();
			    }

		    }
	    }
    }

    public static void main (String args []) 
    {
	inDir = args [0];
	outDir = args [1];
	XMLToText xt = new XMLToText ();

    }
}